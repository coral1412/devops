#coding:utf-8
import time
from pymongo import  MongoClient
from pymongo import  ReadPreference

conn = MongoClient("192.168.10.126:27019,192.168.10.126:27018,192.168.10.126:27019",replicaSet="rs0")
conn.admin.authenticate('test','passwd')
db=conn.get_database("test",read_preference=ReadPreference.SECONDARY_PREFERRED)

#打印Primary服务器
#print conn.primary
#打印所有服务器
#print conn.seeds
#打印Secondary服务器
#print conn.secondaries
#print conn.read_preference
#print conn.server_info()

for i in range(20):
    try:
#        db.test.insert({"name":"test" + str(i),"age":123})
        obj=db.test.find({},{"_id":0,"name":1}).skip(i).limit(1)
        time.sleep(1)
        for item in obj:
            print(item.values())
        #print("All Host:",conn.seeds)
        print("Primary Host:",conn.primary)
        print("Secondary Host:",conn.secondaries)
    except:
        pass
